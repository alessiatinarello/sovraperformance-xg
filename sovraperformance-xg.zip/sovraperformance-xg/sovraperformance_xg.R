# =====================================================================
# Sovra e sottoperformance rispetto agli xG
# Serie A, La Liga e Premier League — stagioni 2017/18 – 2024/25
#
# Modello (per ogni campionato):
#   punti ~ xg_diff + EO + ED | effetti fissi squadra + stagione
# I residui (punti reali - punti predetti) misurano quanto una squadra
# ha fatto meglio (>0) o peggio (<0) di quanto suggerito dai suoi dati.
#
# Autrice: Alessia Tinarello
# =====================================================================

library(dplyr)
library(stringr)
library(ggplot2)
library(lfe)      # install.packages("lfe") se non presente

# ---- Parametri ------------------------------------------------------

# Una cartella per campionato, con un file "TOT DATI <stagione>.csv" per stagione
# (separatore ";" e decimali con la virgola)
campionati <- c(
  "Serie A"        = "data/serie_a",
  "La Liga"        = "data/liga",
  "Premier League" = "data/premier"
)

stagioni <- c("1718", "1819", "1920", "2021", "2122", "2223", "2324", "2425")

colonne_numeriche <- c("GF", "GS", "xG", "xGA", "xg_diff", "EO", "ED", "punti")

dir.create("output", showWarnings = FALSE)

# ---- Funzioni -------------------------------------------------------

# "1718" -> "2017-2018"
etichetta_stagione <- function(codice) {
  paste0("20", substr(codice, 1, 2), "-20", substr(codice, 3, 4))
}

# Converte in numero gestendo virgole decimali e spazi
in_numero <- function(x) as.numeric(gsub(",", ".", trimws(as.character(x))))

# Carica tutte le stagioni di un campionato in un unico dataframe
carica_campionato <- function(cartella) {
  lapply(stagioni, function(s) {
    file <- file.path(cartella, paste0("TOT DATI ", s, ".csv"))
    read.csv2(file, stringsAsFactors = FALSE,
              encoding = "latin1",                # nomi avversari con accenti
              na.strings = c("NA", "", "#DIV/0!")) %>%
      # colonne vuote create da Excel (X, X.1, X.2, ...)
      select(-matches("^X(\\.\\d+)?$", ignore.case = FALSE)) %>%
      mutate(
        across(any_of(colonne_numeriche), in_numero),
        stagione = etichetta_stagione(s)
      )
  }) %>%
    bind_rows()
}

# Corregge le righe malformate e uniforma i nomi delle squadre
pulisci <- function(df) {
  # Premier 22/23: in alcune righe competizione e squadra sono invertite
  # (squadra = "Premier League", competizione = "Man United")
  invertite <- which(df$squadra == "Premier League")
  if (length(invertite) > 0) {
    tmp <- df$squadra[invertite]
    df$squadra[invertite] <- df$competizione[invertite]
    df$competizione[invertite] <- tmp
    message(length(invertite), " righe con squadra/competizione invertite corrette")
  }

  # Righe con colonne sfasate (es. Premier 24/25, 01/02/2025): al posto
  # della competizione c'è il nome di una squadra, quindi i valori non sono
  # affidabili e la riga viene scartata
  sfasate <- !is.na(df$competizione) & df$competizione %in% df$squadra
  if (any(sfasate)) {
    message("Scartate ", sum(sfasate), " righe con colonne sfasate: ",
            paste(df$stagione[sfasate], df$data[sfasate], collapse = ", "))
  }

  df %>%
    filter(
      !sfasate,
      !is.na(squadra), squadra != "",     # righe vuote in fondo ai file
      !is.na(punti)
    ) %>%
    mutate(squadra = case_when(
      squadra %in% c("Man United", "Manchester United", "Man Utd") ~ "Man Utd",
      TRUE ~ squadra
    ))
}

# Da dati partita a dati squadra-stagione
aggrega <- function(df) {
  df %>%
    group_by(stagione, squadra) %>%
    summarise(
      GF      = sum(GF, na.rm = TRUE),
      GS      = sum(GS, na.rm = TRUE),
      xG      = mean(xG, na.rm = TRUE),
      xGA     = mean(xGA, na.rm = TRUE),
      xg_diff = mean(xg_diff, na.rm = TRUE),
      EO      = mean(EO, na.rm = TRUE),
      ED      = mean(ED, na.rm = TRUE),
      punti   = sum(punti, na.rm = TRUE),
      .groups = "drop"
    )
}

# Stima il modello a effetti fissi e calcola predetti e residui
stima_modello <- function(agg) {
  dati <- agg %>% filter(complete.cases(punti, xg_diff, EO, ED))

  modello <- felm(punti ~ xg_diff + EO + ED | squadra + stagione, data = dati)

  risultati <- dati %>%
    mutate(
      punti_predetti = as.numeric(modello$fitted.values),
      residui        = punti - punti_predetti
    ) %>%
    arrange(stagione, desc(residui)) %>%
    select(stagione, squadra, punti, punti_predetti, residui, xg_diff, EO, ED)

  list(modello = modello, risultati = risultati)
}

# Heatmap dei residui: le 5 squadre più sovraperformanti e le 5 più
# sottoperformanti in media sull'intero periodo
heatmap_residui <- function(risultati, nome_campionato) {
  media <- risultati %>%
    group_by(squadra) %>%
    summarise(residuo_medio = mean(residui, na.rm = TRUE), .groups = "drop")

  estremi <- media %>%
    arrange(desc(residuo_medio)) %>%
    slice(c(1:5, (n() - 4):n())) %>%
    pull(squadra)

  dati_plot <- risultati %>%
    filter(squadra %in% estremi) %>%
    left_join(media, by = "squadra")

  ggplot(dati_plot, aes(x = reorder(squadra, residuo_medio),
                        y = stagione, fill = residui)) +
    geom_tile(color = "white", width = 0.9, height = 0.9) +
    scale_fill_gradient2(low = "red", mid = "white", high = "green",
                         midpoint = 0, name = "Residui") +
    labs(
      title = paste("Sovra e sottoperformance rispetto agli xG -", nome_campionato),
      x = "Squadra", y = "Stagione"
    ) +
    theme_minimal(base_size = 12) +
    theme(
      plot.background  = element_rect(fill = "white", color = NA),
      panel.grid       = element_blank(),
      axis.text.x      = element_text(angle = 45, hjust = 1, size = 8),
      axis.text.y      = element_text(size = 8),
      plot.title       = element_text(size = 11),
      legend.title     = element_text(size = 10),
      legend.text      = element_text(size = 8)
    )
}

# ---- Analisi --------------------------------------------------------

analisi <- lapply(names(campionati), function(nome) {
  agg <- carica_campionato(campionati[[nome]]) %>%
    pulisci() %>%
    aggrega()

  stima <- stima_modello(agg)

  cat("\n=====", nome, "=====\n")
  print(summary(stima$modello))

  grafico <- heatmap_residui(stima$risultati, nome)
  print(grafico)

  file_base <- str_replace_all(tolower(nome), " ", "_")
  ggsave(file.path("output", paste0("heatmap_", file_base, ".png")),
         grafico, width = 10, height = 6, dpi = 300)
  write.csv2(stima$risultati,
             file.path("output", paste0("residui_", file_base, ".csv")),
             row.names = FALSE)

  stima
})
names(analisi) <- names(campionati)

# Esempio: classifica per residui di una stagione
analisi[["Serie A"]]$risultati %>%
  filter(stagione == "2024-2025") %>%
  print(n = Inf)
