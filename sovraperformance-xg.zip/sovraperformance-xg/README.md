# Creare di più significa vincere?
### Un'analisi data-driven dei top club europei — Serie A, La Liga, Premier League (2017/18 – 2024/25)

Il dominio della partita e l'efficienza realizzativa e difensiva spiegano i punti ottenuti dai top club europei?
Il progetto stima, per ciascun campionato, quanto i punti reali dipendano dal dominio (differenziale xG) e dall'efficienza nelle due fasi. Poi misura quali squadre hanno fatto **meglio o peggio** di quanto suggerito dai loro dati.

## Dati

Dati partita per partita dei club con partecipazione stabile alle coppe europee, **in tutte le competizioni** (campionato, coppe nazionali, coppe europee):

| Campionato | Squadre |
|---|---|
| Serie A | Atalanta, Fiorentina, Inter, Juventus, Lazio, Milan, Napoli, Roma |
| La Liga | Real Madrid, Barcellona, Atletico Madrid, Siviglia |
| Premier League | Arsenal, Chelsea, Liverpool, Man City, Man Utd |

Variabili usate:
- `xg_diff`: xG prodotti − xG concessi (dominio della partita)
- `EO`, efficienza offensiva: gol segnati / xG
- `ED`, efficienza difensiva: gol subiti / xGA (valori più alti indicano una difesa meno efficiente)
- `punti`: 3 / 1 / 0 per vittoria / pareggio / sconfitta

## Modello

I dati vengono aggregati a livello squadra-stagione (somma di punti e gol, media delle metriche). Per ogni campionato si stima un modello a effetti fissi con `lfe::felm`:

```
punti ~ xg_diff + EO + ED | squadra + stagione
```

Gli effetti fissi assorbono la forza strutturale di ogni club (rosa, stile di gioco) e gli shock comuni a ogni annata.
Il **residuo** (punti reali − punti predetti) misura la sovraperformance (> 0) o la sottoperformance (< 0).

## Risultati principali

| | xg_diff | EO | ED | R² |
|---|---|---|---|---|
| Serie A | **44.5*** | 12.5 | 3.5 | 0.74 |
| La Liga | **31.4*** | **80.6*** | **−36.3*** | 0.88 |
| Premier League | **33.5*** | **76.9*** | −7.0 | 0.81 |

<sub>In grassetto con * i coefficienti significativi al 5%.</sub>

- Il **dominio della partita** (xg_diff) è significativo in tutti e tre i campionati.
- In **Serie A** spiega quasi da solo i punti: le due efficienze non risultano significative.
- In **Liga e Premier** pesa molto anche la **capacità di finalizzare** (EO). In Liga conta anche la solidità difensiva (ED): il segno negativo indica che concedere più gol rispetto agli xGA costa punti.

Le heatmap in `output/` mostrano, stagione per stagione, i residui delle squadre più sovraperformanti e più sottoperformanti.

![Serie A](output/heatmap_serie_a.png)
![La Liga](output/heatmap_la_liga.png)
![Premier League](output/heatmap_premier_league.png)

## Struttura

```
sovraperformance_xg.R    script completo
data/serie_a/            TOT DATI 1718.csv … TOT DATI 2425.csv
data/liga/               idem
data/premier/            idem
output/                  heatmap (.png) e tabelle dei residui (.csv)
```

I CSV usano `;` come separatore e la virgola come decimale.
Lo script corregge automaticamente alcune righe malformate dei file Premier:
- 22/23: 4 partite del Man United con squadra e competizione invertite
- 24/25: una riga con colonne sfasate, che viene scartata

## Esecuzione

```r
install.packages(c("dplyr", "stringr", "ggplot2", "lfe"))
source("sovraperformance_xg.R")   # dalla cartella del progetto
```

---
Alessia Tinarello: Football Data & Match Analyst
